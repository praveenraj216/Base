import { Injectable } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";

@Injectable({
    providedIn: 'root'
})

export class formControl {

    constructor(public formbuilder: FormBuilder) {

    }

    personalform() {
        return this.formbuilder.group({
            firstname: ['', Validators.compose([Validators.pattern('[a-zA-Z ]*'), Validators.required])],
            amount: ['', Validators.required],
        });
    }

    personalvalid() {
        return {
            firstname: [
                { type: "required", message: "Please Enter FirstName." },
                { type: "pattern", message: "Enter Valid FirstName." },
                { type: "maxlength", message: "Enter Maximum 30 Characters." }
            ],
            amount: [
                { type: "required", message: "Please Enter Amount." },
            ]
        };
    }



}