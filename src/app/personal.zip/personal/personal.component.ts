import { Component, OnInit } from '@angular/core';
import { FormGroup } from "@angular/forms";

import { formControl } from "./formcontrol";

@Component({
  selector: 'app-personal',
  templateUrl: './personal.component.html',
  styleUrls: ['./personal.component.scss'],
})
export class PersonalComponent implements OnInit {
  loanDetails: FormGroup;
  validation_messages: any;

  constructor(public form: formControl) {

  }

  ngOnInit() {
    this.validation_messages = this.form.personalvalid();
    this.loanDetails = this.form.personalform();
  }

  checkLoan(value) {
    console.log("Vlaue", value);
  }

}
